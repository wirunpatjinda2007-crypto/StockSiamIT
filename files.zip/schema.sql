-- วางทั้งไฟล์ใน Supabase > SQL Editor > Run
-- ตารางผู้ใช้ (พนักงาน/แอดมิน)
-- name = ชื่อที่แสดงในแอป, role = 'admin' (แอดมิน) หรือ 'staff' (พนักงาน)
create table profiles(id uuid primary key references auth.users on delete cascade, name text, role text not null default 'staff' check(role in('admin','staff')));
-- ตารางสินค้า: qty = คงเหลือ, min_qty = ขั้นต่ำที่ต้องมี (ถ้า qty <= min_qty จะขึ้นในหน้า 'ขาดสต๊อก')
create table products(id uuid primary key default gen_random_uuid(), name text not null, unit text default 'ชิ้น', qty numeric not null default 0, min_qty numeric not null default 0, created_at timestamptz default now());
-- ตารางงานที่แอดมินมอบหมาย: assigned_to = id ของผู้รับงาน, status = 'todo' (รอทำ) / 'done' (เสร็จ)
create table tasks(id uuid primary key default gen_random_uuid(), title text not null, note text, product_id uuid references products on delete set null, assigned_to uuid references profiles on delete cascade, status text not null default 'todo' check(status in('todo','done')), created_at timestamptz default now(), done_at timestamptz);

-- ฟังก์ชันเช็กว่าผู้ใช้ปัจจุบันเป็นแอดมินหรือไม่ (ใช้ในกฎความปลอดภัยด้านล่าง)
create function is_admin() returns boolean language sql security definer stable as $$ select exists(select 1 from profiles where id=auth.uid() and role='admin') $$;

-- (คนแรกที่สมัคร = แอดมิน) ===== ชื่อผู้ใช้ใหม่ถูกตั้งตรงนี้ =====
-- คนแรกที่สมัคร = แอดมิน, คนถัดไป = พนักงาน
-- ทำงานอัตโนมัติทุกครั้งที่เพิ่มผู้ใช้ใหม่ใน Supabase Auth
-- - ชื่อเริ่มต้น = ข้อความหน้า @ ของอีเมล: split_part(new.email,'@',1)  <- แก้ตรงนี้ถ้าอยากตั้งชื่อแบบอื่น
-- - คนแรกได้ role 'admin' คนถัดไปได้ 'staff'  <- เปลี่ยนคำว่า 'admin'/'staff' ได้
create function handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id,name,role) values(new.id, split_part(new.email,'@',1), case when exists(select 1 from profiles) then 'staff' else 'admin' end); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- เปิดระบบกันสิทธิ์ (Row Level Security): ผู้ใช้เห็น/แก้ได้เฉพาะที่อนุญาตด้านล่าง
alter table profiles enable row level security;
alter table products enable row level security;
alter table tasks enable row level security;

-- กฎของแต่ละตาราง: ทุกคนที่ล็อกอินอ่านรายชื่อ/สินค้าได้, เฉพาะแอดมินเพิ่ม-ลบสินค้าและมอบงานได้,
-- พนักงานเห็นและแก้ได้เฉพาะงานของตัวเอง
create policy p_sel on profiles for select to authenticated using(true);
create policy p_upd on profiles for update to authenticated using(is_admin());
create policy pr_sel on products for select to authenticated using(true);
create policy pr_ins on products for insert to authenticated with check(is_admin());
create policy pr_upd on products for update to authenticated using(true);
create policy pr_del on products for delete to authenticated using(is_admin());
create policy t_sel on tasks for select to authenticated using(is_admin() or assigned_to=auth.uid());
create policy t_ins on tasks for insert to authenticated with check(is_admin());
create policy t_upd on tasks for update to authenticated using(is_admin() or assigned_to=auth.uid());
create policy t_del on tasks for delete to authenticated using(is_admin());

-- เปิด realtime ให้หน้าเว็บอัปเดตเองเมื่อข้อมูลเปลี่ยน
alter publication supabase_realtime add table products, tasks;

-- ความเห็นจากพนักงาน
create table feedback(id uuid primary key default gen_random_uuid(), user_id uuid references profiles on delete cascade default auth.uid(), message text not null, status text not null default 'todo' check(status in('todo','done')), created_at timestamptz default now());
alter table feedback enable row level security;
create policy f_sel on feedback for select to authenticated using(is_admin() or user_id=auth.uid());
create policy f_ins on feedback for insert to authenticated with check(user_id=auth.uid());
create policy f_upd on feedback for update to authenticated using(is_admin());
create policy f_del on feedback for delete to authenticated using(is_admin() or user_id=auth.uid());
alter publication supabase_realtime add table feedback;

-- ===== วิธีตั้งชื่อ / เปลี่ยนสิทธิ์พนักงานและแอดมิน (ลบ -- หน้าบรรทัดแล้วแก้อีเมลก่อนรัน) =====
-- เปลี่ยนชื่อที่แสดง:
-- update profiles set name = 'สมชาย' where id = (select id from auth.users where email = 'somchai@gmail.com');
-- ตั้งให้เป็นแอดมิน:
-- update profiles set role = 'admin' where id = (select id from auth.users where email = 'somchai@gmail.com');
-- หรือแก้ในหน้าเว็บ Supabase: Table Editor > profiles > คลิกช่อง name / role
